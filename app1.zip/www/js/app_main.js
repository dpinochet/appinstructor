

function onConfirmCerrarSesion(buttonIndex) {
    if (buttonIndex==1) {
    	window.location.href="index.html";
    }
}

function alertDismissed() {

}


function volverIndex() {
  window.location.href="index.html";
}

function agregarCliente() {
  var usuario = localStorage.getItem('usuario');
   cordova.plugins.barcodeScanner.scan(
      function (result) {
         

  var parametros = {
                "op" : 2,
                "rut_instructor" : usuario,
                "rut_cliente" : result.text
        };  

$.ajax({                                      
      url: 'https://www.cmasgym.cl/intranet/api1/',    
      data: parametros,      
type:  'post',
      success: function(data)         
      {
 // alert(data);
        if (data == "1") {
            navigator.notification.alert(
    'El Cliente ya está siendo entrenado por otro instructor',  // message
    alertDismissed,         // callback
    'Agregar Cliente',            // title
    'Aceptar'                  // buttonName
);
        }
        else {
          verGrilla();
        }
      }

      
    });

               
      },
      function (error) {
          alert("Scanning failed: " + error);
      }
   );

      

}


$( document ).ready(function() {
  var nombre = localStorage.getItem('nombre');
  //console.log("nombre=" + nombre);
  if (!nombre) {
    window.location.href="index.html";
  }
  else {
  $("#nombreInstructor").html(nombre);
  verGrilla();
}
});




function verGrilla() {
var usuario = localStorage.getItem('usuario');
var parametros = {
                "op" : 3,
                "rut_instructor" : usuario
        };  

$.ajax({                                      
      url: 'https://www.cmasgym.cl/intranet/api1/',    
      data: parametros,      
type:  'post',
      success: function(data)         
      {
  //console.log(data);
      $('#grilla').html(data);

      }
    

    });

}


function eliminar(id) {
  localStorage.setItem("varEliminar", id);
  navigator.notification.confirm(
            '¿Desea quitar este cliente de su entrenamiento?', // message
             eliminarCliente,            // callback to invoke with index of button pressed
            'Quitar Cliente',           // title
            ['Quitar','Cancelar']         // buttonLabels
        );
 } 

function eliminarCliente(buttonIndex) {
  //alert(buttonIndex);
if (buttonIndex == 1) {
  var id = localStorage.getItem('varEliminar')
  var usuario = localStorage.getItem('usuario');

var parametros = {
                "op" : 4,
                "rut_instructor" : usuario,
                "rut_cliente" : id
        };  

$.ajax({                                      
      url: 'https://www.cmasgym.cl/intranet/api1/',    
      data: parametros,      
type:  'post',
      success: function(data)         
      {
       verGrilla();
       localStorage.setItem("varEliminar", id);
      }
    

    });
}

}



function iniciar(id) {
    


  localStorage.setItem("varIniciar", id);
  navigator.notification.confirm(
            '¿Desea iniciar entramiento para este cliente?', // message
             iniciar2,            // callback to invoke with index of button pressed
            'Iniciar Entranamiento Cliente',           // title
            ['Iniciar','Cancelar']         // buttonLabels
        );
 } 

function iniciar2(buttonIndex) {
if (buttonIndex == 1) {
  var id = localStorage.getItem('varIniciar')
  var usuario = localStorage.getItem('usuario');

var parametros = {
                "op" : 5,
                "rut_instructor" : usuario,
                "rut_cliente" : id
        };  

$.ajax({                                      
      url: 'https://www.cmasgym.cl/intranet/api1/',    
      data: parametros,      
type:  'post',
      success: function(data)         
      {
       verGrilla();
       localStorage.setItem("varIniciar", "");
       //ajaxindicatorstop();
      }
    

    });
}
      // ajaxindicatorstop();


}


function finalizar(id) {
  localStorage.setItem("varFin", id);
  navigator.notification.confirm(
            '¿Desea finalizar el entramiento para este cliente?', // message
             finalizar2,            // callback to invoke with index of button pressed
            'Finalizar Entranamiento Cliente',           // title
            ['Finalizar','Cancelar']         // buttonLabels
        );
 } 

function finalizar2(buttonIndex) {
  //alert(buttonIndex);
if (buttonIndex == 1) {
  var id = localStorage.getItem('varFin')
  var usuario = localStorage.getItem('usuario');

var parametros = {
                "op" : 6,
                "rut_instructor" : usuario,
                "rut_cliente" : id
        };  

$.ajax({                                      
      url: 'https://www.cmasgym.cl/intranet/api1/',    
      data: parametros,      
type:  'post',
      success: function(data)         
      {
    //console.log(data);
       verGrilla();
       localStorage.setItem("varFin", "");
      }
    

    });
}

}

function ajaxInicio() {
  $('#ajaxProceso').fadeIn(700);
  //console.log("ajax inicio");
}

function ajaxFin() {
  $('#ajaxProceso').fadeOut(300);
  //console.log("ajax inicio");
}


 jQuery(document).ajaxStart(function () {
    ajaxInicio();
}).ajaxStop(function () {
ajaxFin();
});


