function entrar() {
	var usuario = $("#usuario").val();
	var clave = $("#clave").val();


	var parametros = {
                "op" : 1,
"usuario" : usuario,
"clave" : clave
        };  

  $.ajax({                                      
      url: 'https://www.cmasgym.cl/intranet/api1/',    
      data: parametros,      
type:  'post',
      success: function(data)         
      {
		var info = data.split(';');
        if (info[0] == "1") {
		localStorage.setItem("usuario", usuario);
		localStorage.setItem("nombre", info[1]);
		localStorage.setItem("email", info[2]);
		window.location.href="main.html";
		}
		else {
			navigator.notification.alert(
    'Usuario o Contraseña incorrecto',  // message
    alertDismissed,         // callback
    'Inicio Sesión Instructor',            // title
    'Aceptar'                  // buttonName
);
		}

      } 
    });



	

}


function alertDismissed() {

}



function ajaxInicio() {
  $('#ajaxProceso').fadeIn(700);
  //console.log("ajax inicio");
}

function ajaxFin() {
  $('#ajaxProceso').fadeOut(300);
  //console.log("ajax inicio");
}


 jQuery(document).ajaxStart(function () {
    ajaxInicio();
}).ajaxStop(function () {
ajaxFin();
});


		
